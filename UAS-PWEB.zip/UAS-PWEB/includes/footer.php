</div><!-- end container -->

<footer class="footer mt-auto py-3 bg-primary text-white text-center">
    <div class="container">
        <span><i class="bi bi-mortarboard-fill me-1"></i> Sistem Pendataan Mahasiswa &copy; <?= date('Y') ?></span>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
